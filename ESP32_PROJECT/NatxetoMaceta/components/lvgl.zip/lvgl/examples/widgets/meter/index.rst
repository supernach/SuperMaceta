
Simple meter
"""""""""""""""""""""""

.. lv_example:: widgets/meter/lv_example_meter_1
  :language: c


A meter with multiple arcs
"""""""""""""""""""""""""""

.. lv_example:: widgets/meter/lv_example_meter_2
  :language: c


A clock from a meter
"""""""""""""""""""""""

.. lv_example:: widgets/meter/lv_example_meter_3
  :language: c


Pie chart
"""""""""""""""""""""""

.. lv_example:: widgets/meter/lv_example_meter_4
  :language: c

